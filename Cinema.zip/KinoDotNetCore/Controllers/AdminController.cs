﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KinoDotNetCore.Models;
using KinoDotNetCore.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KinoDotNetCore.Controllers
{
    public class AdminController : Controller
    {
        private KinoContext _context;

        public AdminController(KinoContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(EmployeeLoginDetails employeeLoginDetails)
        {
            if (ModelState.IsValid)
            {
                Pracownicy pracownik = _context.Pracownicy.Where(e => e.Login == employeeLoginDetails.Login && e.Haslo == employeeLoginDetails.Haslo).FirstOrDefault();
                //List<Seanse> seanse = _context.Seanse.Where(e => e.FilmyId == 0).ToList();
                if (pracownik == null)
                {
                    return RedirectToAction("Index", "Home");
                } else
                {
                    if(pracownik.Admin == "t")
                    {
                        return RedirectToAction("Index", "AdminPanel");
                    } else
                    {
                        return RedirectToAction("Index", "EmployeePanel");
                    }
                }
            }

            return View(employeeLoginDetails);

        }
    }
}