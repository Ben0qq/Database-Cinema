﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KinoDotNetCore.Models;

namespace KinoDotNetCore.Controllers
{
    public class SeansesController : Controller
    {
        private readonly KinoContext _context;

        public SeansesController(KinoContext context)
        {
            _context = context;
        }

        // GET: Seanses
        public async Task<IActionResult> Index()
        {
            var kinoContext = _context.Seanse.Include(s => s.Filmy).Include(s => s.Sale);
            return View(await kinoContext.ToListAsync());
        }

        // GET: Seanses/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var seanse = await _context.Seanse
                .Include(s => s.Filmy)
                .Include(s => s.Sale)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (seanse == null)
            {
                return NotFound();
            }

            return View(seanse);
        }

        // GET: Seanses/Create
        public IActionResult Create()
        {
            ViewData["FilmyId"] = new SelectList(_context.Filmy, "Id", "FilmyId");
            ViewData["SaleId"] = new SelectList(_context.Sale, "Id", "SaleId");
            return View();
        }

        // POST: Seanses/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Dzien,Godzina,FilmyId,SaleId")] Seanse seanse)
        {
            if (ModelState.IsValid)
            {
                _context.Add(seanse);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FilmyId"] = new SelectList(_context.Filmy, "Id", "FilmyId", seanse.FilmyId);
            ViewData["SaleId"] = new SelectList(_context.Sale, "Id", "SaleId", seanse.SaleId);
            return View(seanse);
        }

        // GET: Seanses/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var seanse = await _context.Seanse.FindAsync(id);
            if (seanse == null)
            {
                return NotFound();
            }
            ViewData["FilmyId"] = new SelectList(_context.Filmy, "Id", "Tytul", seanse.FilmyId);
            ViewData["SaleId"] = new SelectList(_context.Sale, "Id", "Id", seanse.SaleId);
            return View(seanse);
        }

        // POST: Seanses/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Dzien,Godzina,FilmyId,SaleId")] Seanse seanse)
        {
            if (id != seanse.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(seanse);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SeanseExists(seanse.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FilmyId"] = new SelectList(_context.Filmy, "Id", "Tytul", seanse.FilmyId);
            ViewData["SaleId"] = new SelectList(_context.Sale, "Id", "Id", seanse.SaleId);
            return View(seanse);
        }

        // GET: Seanses/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var seanse = await _context.Seanse
                .Include(s => s.Filmy)
                .Include(s => s.Sale)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (seanse == null)
            {
                return NotFound();
            }

            return View(seanse);
        }

        // POST: Seanses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var seanse = await _context.Seanse.FindAsync(id);
            _context.Seanse.Remove(seanse);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SeanseExists(int id)
        {
            return _context.Seanse.Any(e => e.Id == id);
        }
    }
}
