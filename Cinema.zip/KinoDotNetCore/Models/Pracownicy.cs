﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace KinoDotNetCore.Models
{
    public partial class Pracownicy
    {
        public int Id { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        [DisplayName("Data urodzenia")]

        public DateTime DataUrodzenia { get; set; }
        [DisplayName("Data zatrudnienia")]
        public DateTime DataZatrudnienia { get; set; }
        public string Admin { get; set; }
        public string Login { get; set; }
        public string Haslo { get; set; }
    }
}
