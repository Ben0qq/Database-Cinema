﻿using KinoDotNetCore.Models;

namespace KinoDotNetCore.Repositories
{
    public interface IUnitOfWork
    {
        IKinoGeneric<Filmy> FilmyRepository { get; }
        //IKinoGeneric<Seanse> SeanseRepository { get; }
        //IKinoGeneric<Klienci> KlienciRepository { get; }
        //IKinoGeneric<Opinie> OpinieRepository { get; }
        //IKinoGeneric<Pracownicy> PracownicyRepository { get; }

        void Save();
    }
}