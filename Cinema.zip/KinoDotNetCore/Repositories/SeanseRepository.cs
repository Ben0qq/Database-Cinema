﻿using KinoDotNetCore.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinoDotNetCore.Repositories
{
    public class SeanseRepository : ISeanseRepository
    {
        private readonly KinoContext _context;

        public SeanseRepository(KinoContext context)
        {
            _context = context;
        }

        public List<Seanse> getScreeningsByMovieID(int filmId)
        {
            List<Seanse> seanse = _context.Seanse.Where(x => x.FilmyId == filmId).Include(s=> s.Filmy).Include(s=>s.Sale).ToList();

            return seanse;
        }

    }
}
