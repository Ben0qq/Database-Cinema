﻿using KinoDotNetCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinoDotNetCore.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private KinoContext context;
        private KinoGeneric<Filmy> filmyRepository;

        public IKinoGeneric<Filmy> FilmyRepository
        {
            get
            {
                return filmyRepository = filmyRepository ?? new KinoGeneric<Filmy>(context);
            }
        }

        public UnitOfWork(KinoContext dbContext)
        {
            this.context = dbContext;
        }

        public void Save()
        {
            throw new NotImplementedException();
        }
    }
}
