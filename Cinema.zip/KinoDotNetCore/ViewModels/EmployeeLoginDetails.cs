﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinoDotNetCore.ViewModels
{
    public class EmployeeLoginDetails
    {
        public string Login { get; set; }

        public string Haslo { get; set; }
    }
}
